package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ModelPackage
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-10-07T20:30:20.858Z[GMT]")


public class ModelPackage   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("userID")
  private String userID = null;

  @JsonProperty("transporterID")
  private String transporterID = null;

  @JsonProperty("from")
  private String from = null;

  @JsonProperty("to")
  private String to = null;

  @JsonProperty("deadline")
  private String deadline = null;

  @JsonProperty("price")
  private Long price = null;

  @JsonProperty("weight")
  private BigDecimal weight = null;

  @JsonProperty("height")
  private BigDecimal height = null;

  @JsonProperty("width")
  private BigDecimal width = null;

  @JsonProperty("depth")
  private BigDecimal depth = null;

  @JsonProperty("status")
  private String status = null;

  public ModelPackage id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public ModelPackage userID(String userID) {
    this.userID = userID;
    return this;
  }

  /**
   * Get userID
   * @return userID
   **/
  @Schema(description = "")
  
    public String getUserID() {
    return userID;
  }

  public void setUserID(String userID) {
    this.userID = userID;
  }

  public ModelPackage transporterID(String transporterID) {
    this.transporterID = transporterID;
    return this;
  }

  /**
   * Get transporterID
   * @return transporterID
   **/
  @Schema(description = "")
  
    public String getTransporterID() {
    return transporterID;
  }

  public void setTransporterID(String transporterID) {
    this.transporterID = transporterID;
  }

  public ModelPackage from(String from) {
    this.from = from;
    return this;
  }

  /**
   * Get from
   * @return from
   **/
  @Schema(description = "")
  
    public String getFrom() {
    return from;
  }

  public void setFrom(String from) {
    this.from = from;
  }

  public ModelPackage to(String to) {
    this.to = to;
    return this;
  }

  /**
   * Get to
   * @return to
   **/
  @Schema(description = "")
  
    public String getTo() {
    return to;
  }

  public void setTo(String to) {
    this.to = to;
  }

  public ModelPackage deadline(String deadline) {
    this.deadline = deadline;
    return this;
  }

  /**
   * Get deadline
   * @return deadline
   **/
  @Schema(description = "")
  
    public String getDeadline() {
    return deadline;
  }

  public void setDeadline(String deadline) {
    this.deadline = deadline;
  }

  public ModelPackage price(Long price) {
    this.price = price;
    return this;
  }

  /**
   * Get price
   * @return price
   **/
  @Schema(description = "")
  
    public Long getPrice() {
    return price;
  }

  public void setPrice(Long price) {
    this.price = price;
  }

  public ModelPackage weight(BigDecimal weight) {
    this.weight = weight;
    return this;
  }

  /**
   * Get weight
   * @return weight
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getWeight() {
    return weight;
  }

  public void setWeight(BigDecimal weight) {
    this.weight = weight;
  }

  public ModelPackage height(BigDecimal height) {
    this.height = height;
    return this;
  }

  /**
   * Get height
   * @return height
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getHeight() {
    return height;
  }

  public void setHeight(BigDecimal height) {
    this.height = height;
  }

  public ModelPackage width(BigDecimal width) {
    this.width = width;
    return this;
  }

  /**
   * Get width
   * @return width
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getWidth() {
    return width;
  }

  public void setWidth(BigDecimal width) {
    this.width = width;
  }

  public ModelPackage depth(BigDecimal depth) {
    this.depth = depth;
    return this;
  }

  /**
   * Get depth
   * @return depth
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getDepth() {
    return depth;
  }

  public void setDepth(BigDecimal depth) {
    this.depth = depth;
  }

  public ModelPackage status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  @Schema(description = "")
  
    public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ModelPackage _package = (ModelPackage) o;
    return Objects.equals(this.id, _package.id) &&
        Objects.equals(this.userID, _package.userID) &&
        Objects.equals(this.transporterID, _package.transporterID) &&
        Objects.equals(this.from, _package.from) &&
        Objects.equals(this.to, _package.to) &&
        Objects.equals(this.deadline, _package.deadline) &&
        Objects.equals(this.price, _package.price) &&
        Objects.equals(this.weight, _package.weight) &&
        Objects.equals(this.height, _package.height) &&
        Objects.equals(this.width, _package.width) &&
        Objects.equals(this.depth, _package.depth) &&
        Objects.equals(this.status, _package.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, userID, transporterID, from, to, deadline, price, weight, height, width, depth, status);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ModelPackage {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    userID: ").append(toIndentedString(userID)).append("\n");
    sb.append("    transporterID: ").append(toIndentedString(transporterID)).append("\n");
    sb.append("    from: ").append(toIndentedString(from)).append("\n");
    sb.append("    to: ").append(toIndentedString(to)).append("\n");
    sb.append("    deadline: ").append(toIndentedString(deadline)).append("\n");
    sb.append("    price: ").append(toIndentedString(price)).append("\n");
    sb.append("    weight: ").append(toIndentedString(weight)).append("\n");
    sb.append("    height: ").append(toIndentedString(height)).append("\n");
    sb.append("    width: ").append(toIndentedString(width)).append("\n");
    sb.append("    depth: ").append(toIndentedString(depth)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

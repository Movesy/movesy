package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Review
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-10-07T20:30:20.858Z[GMT]")


public class Review   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("transporterID")
  private String transporterID = null;

  @JsonProperty("packageID")
  private String packageID = null;

  @JsonProperty("time")
  private String time = null;

  @JsonProperty("rating")
  private BigDecimal rating = null;

  @JsonProperty("description")
  private String description = null;

  @JsonProperty("CustomerUsername")
  private String customerUsername = null;

  public Review id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   **/
  @Schema(description = "")
  
    public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Review transporterID(String transporterID) {
    this.transporterID = transporterID;
    return this;
  }

  /**
   * Get transporterID
   * @return transporterID
   **/
  @Schema(description = "")
  
    public String getTransporterID() {
    return transporterID;
  }

  public void setTransporterID(String transporterID) {
    this.transporterID = transporterID;
  }

  public Review packageID(String packageID) {
    this.packageID = packageID;
    return this;
  }

  /**
   * Get packageID
   * @return packageID
   **/
  @Schema(description = "")
  
    public String getPackageID() {
    return packageID;
  }

  public void setPackageID(String packageID) {
    this.packageID = packageID;
  }

  public Review time(String time) {
    this.time = time;
    return this;
  }

  /**
   * Get time
   * @return time
   **/
  @Schema(description = "")
  
    public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  public Review rating(BigDecimal rating) {
    this.rating = rating;
    return this;
  }

  /**
   * Get rating
   * @return rating
   **/
  @Schema(description = "")
  
    @Valid
    public BigDecimal getRating() {
    return rating;
  }

  public void setRating(BigDecimal rating) {
    this.rating = rating;
  }

  public Review description(String description) {
    this.description = description;
    return this;
  }

  /**
   * Get description
   * @return description
   **/
  @Schema(description = "")
  
    public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Review customerUsername(String customerUsername) {
    this.customerUsername = customerUsername;
    return this;
  }

  /**
   * Get customerUsername
   * @return customerUsername
   **/
  @Schema(description = "")
  
    public String getCustomerUsername() {
    return customerUsername;
  }

  public void setCustomerUsername(String customerUsername) {
    this.customerUsername = customerUsername;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Review review = (Review) o;
    return Objects.equals(this.id, review.id) &&
        Objects.equals(this.transporterID, review.transporterID) &&
        Objects.equals(this.packageID, review.packageID) &&
        Objects.equals(this.time, review.time) &&
        Objects.equals(this.rating, review.rating) &&
        Objects.equals(this.description, review.description) &&
        Objects.equals(this.customerUsername, review.customerUsername);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, transporterID, packageID, time, rating, description, customerUsername);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Review {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    transporterID: ").append(toIndentedString(transporterID)).append("\n");
    sb.append("    packageID: ").append(toIndentedString(packageID)).append("\n");
    sb.append("    time: ").append(toIndentedString(time)).append("\n");
    sb.append("    rating: ").append(toIndentedString(rating)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    customerUsername: ").append(toIndentedString(customerUsername)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
